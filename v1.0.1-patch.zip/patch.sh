#!/bin/bash

sudo apt update
sudo apt upgrade -y
sudo apt full-upgrade -y
sudo apt autoremove -y

cp media/install-exagear.sh /home/pi
chmod +x /home/pi/install-exagear.sh


